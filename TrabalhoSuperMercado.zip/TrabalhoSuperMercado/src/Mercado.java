
import java.util.Scanner;

public class Mercado {
    public static void main(String[] args) { 
    
        Scanner teclado = new Scanner(System.in);
        
        String nome;
        float valor;
        int quantidade;
        float total=0;
        
        System.out.println("Olá, somos do mercado do zé. Nos informe a quantidade de produtos comprados: ");
        int compra = teclado.nextInt();
        
        int qntdproduto[] = new int [compra];
        float valorproduto[] = new float [compra];
        String nomeproduto[] = new String [compra];
       
       
        for (int x=0 ; x < compra; x++){
            System.out.println("Digite o nome do produto: ");
            nome = teclado.next();
            nomeproduto[x] = nome; //nome do produto (vetor) recebe o nome do produto do usuario
            
            System.out.println("Digite o valor do produto: ");
            valor = teclado.nextFloat();
            valorproduto[x] = valor; //valor do produto (vetor) recebe o valor do produto do usuario
          
            System.out.println("Digite a quantidade do produto: ");
            quantidade = teclado.nextInt();
            qntdproduto[x] = quantidade; //qntd do produto (vetor) recebe a quantidade do produto do usuario
            
            total += valor*quantidade;
           
        }
        
        for (int x=0; x<compra; x++){
            System.out.println(+ qntdproduto[x]+"x" + "---"+ nomeproduto[x] + "---" + "R$" +valorproduto[x] );
        }
            System.out.println("Total da compra: R$" + total);
             System.out.println("****************");
              System.out.println("AGRADECEMOS A PREFERENCIA!");
        
    }

}


